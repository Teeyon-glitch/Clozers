-- Insert sample leads
INSERT INTO leads (name, email, phone, source, status, budget, location, notes) VALUES
  ('John Smith', 'john.smith@email.com', '555-0101', 'website', 'new', 500000, 'San Francisco, CA', 'Looking for a 3-bedroom house'),
  ('Sarah Johnson', 'sarah.j@email.com', '555-0102', 'referral', 'qualified', 750000, 'Oakland, CA', 'Interested in modern condos'),
  ('Michael Brown', 'mbrown@email.com', '555-0103', 'social_media', 'contacted', 600000, 'Berkeley, CA', 'First-time buyer'),
  ('Emily Davis', 'emily.davis@email.com', '555-0104', 'website', 'qualified', 900000, 'San Francisco, CA', 'Looking for investment property'),
  ('David Wilson', 'dwilson@email.com', '555-0105', 'referral', 'new', 450000, 'San Jose, CA', 'Needs to relocate for work');

-- Insert sample properties
INSERT INTO properties (address, city, state, zip_code, property_type, status, price, bedrooms, bathrooms, square_feet, year_built, description) VALUES
  ('123 Main St', 'San Francisco', 'CA', '94102', 'house', 'available', 850000, 3, 2.5, 1800, 2015, 'Beautiful modern home in prime location'),
  ('456 Oak Ave', 'Oakland', 'CA', '94601', 'condo', 'available', 650000, 2, 2, 1200, 2018, 'Luxury condo with city views'),
  ('789 Pine Rd', 'Berkeley', 'CA', '94704', 'house', 'under_contract', 720000, 4, 3, 2200, 2010, 'Spacious family home near schools'),
  ('321 Elm St', 'San Jose', 'CA', '95110', 'townhouse', 'available', 580000, 3, 2.5, 1600, 2020, 'Modern townhouse in gated community'),
  ('654 Maple Dr', 'San Francisco', 'CA', '94103', 'condo', 'sold', 920000, 2, 2, 1400, 2019, 'Penthouse with panoramic views');

-- Insert sample deals
INSERT INTO deals (title, lead_id, property_id, stage, value, probability, expected_close_date, notes)
SELECT 
  'Deal for ' || l.name,
  l.id,
  p.id,
  CASE 
    WHEN random() < 0.2 THEN 'lead'
    WHEN random() < 0.4 THEN 'qualified'
    WHEN random() < 0.6 THEN 'proposal'
    WHEN random() < 0.8 THEN 'negotiation'
    ELSE 'closed_won'
  END,
  p.price,
  (random() * 50 + 30)::INTEGER,
  CURRENT_DATE + (random() * 90)::INTEGER,
  'Sample deal notes'
FROM leads l
CROSS JOIN LATERAL (
  SELECT id, price FROM properties ORDER BY random() LIMIT 1
) p
LIMIT 5;

-- Insert sample activities
INSERT INTO activities (type, title, description, lead_id)
SELECT 
  CASE 
    WHEN random() < 0.25 THEN 'call'
    WHEN random() < 0.5 THEN 'email'
    WHEN random() < 0.75 THEN 'meeting'
    ELSE 'viewing'
  END,
  'Contact with ' || name,
  'Follow-up discussion about property requirements',
  id
FROM leads
LIMIT 10;

-- Insert sample tasks
INSERT INTO tasks (title, description, due_date, priority, completed, lead_id)
SELECT 
  'Follow up with ' || name,
  'Schedule property viewing and discuss financing options',
  CURRENT_DATE + (random() * 14)::INTEGER,
  CASE 
    WHEN random() < 0.33 THEN 'low'
    WHEN random() < 0.66 THEN 'medium'
    ELSE 'high'
  END,
  random() < 0.3,
  id
FROM leads
LIMIT 8;
