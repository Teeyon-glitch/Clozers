"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { createServerClient } from "@/lib/supabase/server"
import { Mail, Phone } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { LeadActions } from "./lead-actions"
import { LeadDetailButton } from "./lead-detail-button"

const statusColors = {
  new: "default",
  contacted: "secondary",
  qualified: "default",
  unqualified: "secondary",
} as const

const sourceColors = {
  website: "default",
  referral: "secondary",
  social_media: "default",
  direct: "secondary",
  other: "outline",
} as const

export async function LeadsTable({
  searchParams,
}: {
  searchParams?: { search?: string; status?: string; source?: string }
}) {
  const supabase = await createServerClient()

  let query = supabase.from("leads").select("*")

  if (searchParams?.search) {
    query = query.or(
      `name.ilike.%${searchParams.search}%,email.ilike.%${searchParams.search}%,company.ilike.%${searchParams.search}%`,
    )
  }

  if (searchParams?.status && searchParams.status !== "all") {
    query = query.eq("status", searchParams.status)
  }

  if (searchParams?.source && searchParams.source !== "all") {
    query = query.eq("source", searchParams.source)
  }

  const { data: leads } = await query.order("created_at", { ascending: false })

  const leadsList = leads || []

  if (leadsList.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-lg border border-dashed py-16">
        <p className="text-sm text-muted-foreground">No leads found. Create your first lead to get started.</p>
      </div>
    )
  }

  return (
    <div className="rounded-lg border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Contact</TableHead>
            <TableHead>Source</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Budget</TableHead>
            <TableHead>Created</TableHead>
            <TableHead className="w-12"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {leadsList.map((lead) => (
            <TableRow key={lead.id} className="cursor-pointer hover:bg-muted/50">
              <TableCell onClick={() => {}}>
                <LeadDetailButton lead={lead}>
                  <div className="flex flex-col">
                    <span className="font-medium">{lead.name}</span>
                    {lead.company && <span className="text-xs text-muted-foreground">{lead.company}</span>}
                  </div>
                </LeadDetailButton>
              </TableCell>
              <TableCell>
                <div className="flex flex-col gap-1">
                  {lead.email && (
                    <div className="flex items-center gap-1.5 text-sm">
                      <Mail className="size-3 text-muted-foreground" />
                      <span className="text-muted-foreground">{lead.email}</span>
                    </div>
                  )}
                  {lead.phone && (
                    <div className="flex items-center gap-1.5 text-sm">
                      <Phone className="size-3 text-muted-foreground" />
                      <span className="text-muted-foreground">{lead.phone}</span>
                    </div>
                  )}
                </div>
              </TableCell>
              <TableCell>
                <Badge variant={sourceColors[lead.source as keyof typeof sourceColors] || "outline"}>
                  {lead.source?.replace("_", " ")}
                </Badge>
              </TableCell>
              <TableCell>
                <Badge variant={statusColors[lead.status as keyof typeof statusColors] || "default"}>
                  {lead.status}
                </Badge>
              </TableCell>
              <TableCell>
                {lead.budget ? `$${lead.budget.toLocaleString()}` : <span className="text-muted-foreground">—</span>}
              </TableCell>
              <TableCell className="text-sm text-muted-foreground">
                {formatDistanceToNow(new Date(lead.created_at), { addSuffix: true })}
              </TableCell>
              <TableCell onClick={(e) => e.stopPropagation()}>
                <LeadActions lead={lead} />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
