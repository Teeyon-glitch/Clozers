"use client"

import type React from "react"

import { useState } from "react"
import { LeadDetailModal } from "./lead-detail-modal"

interface LeadDetailButtonProps {
  lead: any
  children: React.ReactNode
}

export function LeadDetailButton({ lead, children }: LeadDetailButtonProps) {
  const [open, setOpen] = useState(false)

  return (
    <>
      <div onClick={() => setOpen(true)}>{children}</div>
      <LeadDetailModal lead={lead} open={open} onOpenChange={setOpen} />
    </>
  )
}
