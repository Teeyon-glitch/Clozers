"use client"

import { useEffect, useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Mail, Phone, Building2, DollarSign, Calendar, FileText, TrendingUp, MessageSquare } from "lucide-react"
import { formatDistanceToNow, format } from "date-fns"
import { createBrowserClient } from "@/lib/supabase/client"

interface LeadDetailModalProps {
  lead: any
  open: boolean
  onOpenChange: (open: boolean) => void
}

const statusColors = {
  new: "default",
  contacted: "secondary",
  qualified: "default",
  unqualified: "secondary",
} as const

const sourceColors = {
  website: "default",
  referral: "secondary",
  social_media: "default",
  direct: "secondary",
  other: "outline",
} as const

export function LeadDetailModal({ lead, open, onOpenChange }: LeadDetailModalProps) {
  const [activities, setActivities] = useState<any[]>([])
  const [deals, setDeals] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const supabase = createBrowserClient()

  useEffect(() => {
    if (open && lead) {
      fetchRelatedData()
    }
  }, [open, lead])

  const fetchRelatedData = async () => {
    setLoading(true)
    try {
      const [activitiesResult, dealsResult] = await Promise.all([
        supabase.from("activities").select("*").eq("lead_id", lead.id).order("created_at", { ascending: false }),
        supabase
          .from("deals")
          .select("*, properties(address)")
          .eq("lead_id", lead.id)
          .order("created_at", { ascending: false }),
      ])

      setActivities(activitiesResult.data || [])
      setDeals(dealsResult.data || [])
    } catch (error) {
      console.error("Failed to fetch related data:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <DialogTitle className="text-2xl">{lead.name}</DialogTitle>
              <div className="flex items-center gap-2">
                <Badge variant={statusColors[lead.status as keyof typeof statusColors] || "default"}>
                  {lead.status}
                </Badge>
                <Badge variant={sourceColors[lead.source as keyof typeof sourceColors] || "outline"}>
                  {lead.source?.replace("_", " ")}
                </Badge>
              </div>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Contact Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Contact Information</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              {lead.email && (
                <div className="flex items-center gap-3">
                  <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10">
                    <Mail className="size-5 text-primary" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xs text-muted-foreground">Email</span>
                    <span className="text-sm font-medium">{lead.email}</span>
                  </div>
                </div>
              )}

              {lead.phone && (
                <div className="flex items-center gap-3">
                  <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10">
                    <Phone className="size-5 text-primary" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xs text-muted-foreground">Phone</span>
                    <span className="text-sm font-medium">{lead.phone}</span>
                  </div>
                </div>
              )}

              {lead.company && (
                <div className="flex items-center gap-3">
                  <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10">
                    <Building2 className="size-5 text-primary" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xs text-muted-foreground">Company</span>
                    <span className="text-sm font-medium">{lead.company}</span>
                  </div>
                </div>
              )}

              {lead.budget && (
                <div className="flex items-center gap-3">
                  <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10">
                    <DollarSign className="size-5 text-primary" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xs text-muted-foreground">Budget</span>
                    <span className="text-sm font-medium">${lead.budget.toLocaleString()}</span>
                  </div>
                </div>
              )}

              <div className="flex items-center gap-3">
                <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10">
                  <Calendar className="size-5 text-primary" />
                </div>
                <div className="flex flex-col">
                  <span className="text-xs text-muted-foreground">Created</span>
                  <span className="text-sm font-medium">{format(new Date(lead.created_at), "MMM d, yyyy")}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Notes */}
          {lead.notes && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Notes</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{lead.notes}</p>
              </CardContent>
            </Card>
          )}

          {/* Tabs for Activities and Deals */}
          <Tabs defaultValue="deals" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="deals">
                <TrendingUp className="mr-2 size-4" />
                Deals ({deals.length})
              </TabsTrigger>
              <TabsTrigger value="activities">
                <MessageSquare className="mr-2 size-4" />
                Activities ({activities.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="deals" className="space-y-4">
              {loading ? (
                <div className="py-8 text-center text-sm text-muted-foreground">Loading deals...</div>
              ) : deals.length === 0 ? (
                <div className="py-8 text-center text-sm text-muted-foreground">No deals found for this lead</div>
              ) : (
                deals.map((deal) => (
                  <Card key={deal.id}>
                    <CardContent className="flex items-center justify-between p-4">
                      <div className="space-y-1">
                        <p className="font-medium">{deal.title}</p>
                        {deal.properties && <p className="text-sm text-muted-foreground">{deal.properties.address}</p>}
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">{deal.stage?.replace("_", " ")}</Badge>
                          {deal.probability && (
                            <span className="text-xs text-muted-foreground">{deal.probability}%</span>
                          )}
                        </div>
                      </div>
                      {deal.value && (
                        <div className="text-right">
                          <p className="text-lg font-bold">${deal.value.toLocaleString()}</p>
                          <p className="text-xs text-muted-foreground">
                            {formatDistanceToNow(new Date(deal.created_at), { addSuffix: true })}
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))
              )}
            </TabsContent>

            <TabsContent value="activities" className="space-y-4">
              {loading ? (
                <div className="py-8 text-center text-sm text-muted-foreground">Loading activities...</div>
              ) : activities.length === 0 ? (
                <div className="py-8 text-center text-sm text-muted-foreground">No activities found for this lead</div>
              ) : (
                activities.map((activity) => (
                  <Card key={activity.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="flex size-8 items-center justify-center rounded-full bg-primary/10">
                          <FileText className="size-4 text-primary" />
                        </div>
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center justify-between">
                            <Badge variant="outline">{activity.type}</Badge>
                            <span className="text-xs text-muted-foreground">
                              {formatDistanceToNow(new Date(activity.created_at), { addSuffix: true })}
                            </span>
                          </div>
                          {activity.notes && <p className="text-sm text-muted-foreground">{activity.notes}</p>}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  )
}
