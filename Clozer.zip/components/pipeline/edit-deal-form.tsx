"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { updateDeal } from "@/app/actions/deals"
import { Spinner } from "@/components/ui/spinner"
import { useRouter } from "next/navigation"

const dealSchema = z.object({
  title: z.string().min(1, "Title is required"),
  stage: z.enum(["lead", "qualified", "proposal", "negotiation", "closed_won", "closed_lost"]),
  value: z.string().optional(),
  probability: z.string().optional(),
  expected_close_date: z.string().optional(),
  notes: z.string().optional(),
})

type DealFormData = z.infer<typeof dealSchema>

export function EditDealForm({ deal, onSuccess }: { deal: any; onSuccess: () => void }) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const router = useRouter()

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm<DealFormData>({
    resolver: zodResolver(dealSchema),
    defaultValues: {
      title: deal.title,
      stage: deal.stage,
      value: deal.value?.toString() || "",
      probability: deal.probability?.toString() || "",
      expected_close_date: deal.expected_close_date || "",
      notes: deal.notes || "",
    },
  })

  const onSubmit = async (data: DealFormData) => {
    setIsSubmitting(true)
    try {
      const dealData = {
        ...data,
        value: data.value ? Number.parseFloat(data.value) : null,
        probability: data.probability ? Number.parseInt(data.probability) : null,
        expected_close_date: data.expected_close_date || null,
      }
      await updateDeal(deal.id, dealData)
      router.refresh()
      onSuccess()
    } catch (error) {
      console.error("Failed to update deal:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2 sm:col-span-2">
          <Label htmlFor="title">
            Deal Title <span className="text-destructive">*</span>
          </Label>
          <Input id="title" {...register("title")} placeholder="Property sale - 123 Main St" />
          {errors.title && <p className="text-sm text-destructive">{errors.title.message}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="stage">
            Stage <span className="text-destructive">*</span>
          </Label>
          <Select defaultValue={deal.stage} onValueChange={(value) => setValue("stage", value as any)}>
            <SelectTrigger id="stage">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="lead">Lead</SelectItem>
              <SelectItem value="qualified">Qualified</SelectItem>
              <SelectItem value="proposal">Proposal</SelectItem>
              <SelectItem value="negotiation">Negotiation</SelectItem>
              <SelectItem value="closed_won">Closed Won</SelectItem>
              <SelectItem value="closed_lost">Closed Lost</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="value">Deal Value</Label>
          <Input id="value" type="number" {...register("value")} placeholder="250000" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="probability">Probability (%)</Label>
          <Input id="probability" type="number" min="0" max="100" {...register("probability")} placeholder="75" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="expected_close_date">Expected Close Date</Label>
          <Input id="expected_close_date" type="date" {...register("expected_close_date")} />
        </div>

        <div className="space-y-2 sm:col-span-2">
          <Label htmlFor="notes">Notes</Label>
          <Textarea id="notes" {...register("notes")} placeholder="Additional information about the deal..." rows={4} />
        </div>
      </div>

      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={onSuccess} disabled={isSubmitting}>
          Cancel
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting && <Spinner />}
          Update Deal
        </Button>
      </div>
    </form>
  )
}
