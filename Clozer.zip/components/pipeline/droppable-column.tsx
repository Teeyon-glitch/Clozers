"use client"

import type React from "react"

import { useState } from "react"
import { updateDeal } from "@/app/actions/deals"
import { useRouter } from "next/navigation"

interface DroppableColumnProps {
  stageId: string
  children: React.ReactNode
}

export function DroppableColumn({ stageId, children }: DroppableColumnProps) {
  const [isDragOver, setIsDragOver] = useState(false)
  const router = useRouter()

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(true)
  }

  const handleDragLeave = () => {
    setIsDragOver(false)
  }

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(false)

    const dealId = e.dataTransfer.getData("dealId")
    const currentStage = e.dataTransfer.getData("currentStage")

    if (dealId && currentStage !== stageId) {
      try {
        await updateDeal(dealId, { stage: stageId })
        router.refresh()
      } catch (error) {
        console.error("Failed to update deal stage:", error)
      }
    }
  }

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`transition-colors ${isDragOver ? "rounded-lg bg-primary/5 ring-2 ring-primary/20" : ""}`}
    >
      {children}
    </div>
  )
}
