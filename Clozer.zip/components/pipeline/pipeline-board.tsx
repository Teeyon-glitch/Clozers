import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { createServerClient } from "@/lib/supabase/server"
import { DealCard } from "./deal-card"
import { DroppableColumn } from "./droppable-column"

const stages = [
  { id: "lead", label: "Lead", color: "bg-slate-100 dark:bg-slate-800" },
  { id: "qualified", label: "Qualified", color: "bg-blue-100 dark:bg-blue-900/30" },
  { id: "proposal", label: "Proposal", color: "bg-purple-100 dark:bg-purple-900/30" },
  { id: "negotiation", label: "Negotiation", color: "bg-amber-100 dark:bg-amber-900/30" },
  { id: "closed_won", label: "Closed Won", color: "bg-emerald-100 dark:bg-emerald-900/30" },
  { id: "closed_lost", label: "Closed Lost", color: "bg-red-100 dark:bg-red-900/30" },
]

export async function PipelineBoard() {
  const supabase = await createServerClient()

  const { data: deals } = await supabase
    .from("deals")
    .select("*, leads(name, email), properties(address)")
    .order("created_at", { ascending: false })

  const dealsList = deals || []

  // Group deals by stage
  const dealsByStage = stages.reduce(
    (acc, stage) => {
      acc[stage.id] = dealsList.filter((deal) => deal.stage === stage.id)
      return acc
    },
    {} as Record<string, typeof dealsList>,
  )

  return (
    <div className="flex gap-4 overflow-x-auto pb-4">
      {stages.map((stage) => {
        const stageDeals = dealsByStage[stage.id] || []
        const totalValue = stageDeals.reduce((sum, deal) => sum + (deal.value || 0), 0)

        return (
          <DroppableColumn key={stage.id} stageId={stage.id}>
            <div className="flex min-w-80 flex-col gap-3">
              <div className={`rounded-lg p-4 ${stage.color}`}>
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">{stage.label}</h3>
                  <Badge variant="secondary">{stageDeals.length}</Badge>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">${totalValue.toLocaleString()}</p>
              </div>

              <div className="flex flex-col gap-3">
                {stageDeals.length === 0 ? (
                  <Card>
                    <CardContent className="flex items-center justify-center py-8">
                      <p className="text-sm text-muted-foreground">No deals</p>
                    </CardContent>
                  </Card>
                ) : (
                  stageDeals.map((deal) => <DealCard key={deal.id} deal={deal} />)
                )}
              </div>
            </div>
          </DroppableColumn>
        )
      })}
    </div>
  )
}
