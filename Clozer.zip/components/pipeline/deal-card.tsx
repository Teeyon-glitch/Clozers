"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { MoreHorizontal, User, Home, Calendar, DollarSign, GripVertical } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { deleteDeal } from "@/app/actions/deals"
import { useRouter } from "next/navigation"
import { EditDealForm } from "./edit-deal-form"

interface DealCardProps {
  deal: {
    id: string
    title: string
    value: number | null
    stage: string
    probability: number | null
    expected_close_date: string | null
    created_at: string
    lead_id: string
    property_id: string | null
    notes: string | null
    leads?: { name: string; email: string } | null
    properties?: { address: string } | null
  }
}

export function DealCard({ deal }: DealCardProps) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [showEditDialog, setShowEditDialog] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const router = useRouter()

  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData("dealId", deal.id)
    e.dataTransfer.setData("currentStage", deal.stage)
    e.dataTransfer.effectAllowed = "move"
  }

  const handleDelete = async () => {
    setIsDeleting(true)
    try {
      await deleteDeal(deal.id)
      router.refresh()
      setShowDeleteDialog(false)
    } catch (error) {
      console.error("Failed to delete deal:", error)
    } finally {
      setIsDeleting(false)
    }
  }

  return (
    <>
      <Card draggable onDragStart={handleDragStart} className="cursor-move transition-shadow hover:shadow-md">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-start gap-2 flex-1">
              <GripVertical className="size-4 text-muted-foreground mt-0.5 flex-shrink-0" />
              <CardTitle className="text-base">{deal.title}</CardTitle>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon-sm">
                  <MoreHorizontal className="size-4" />
                  <span className="sr-only">Open menu</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuItem onClick={() => setShowEditDialog(true)}>Edit deal</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-destructive" onClick={() => setShowDeleteDialog(true)}>
                  Delete deal
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {deal.value && (
            <div className="flex items-center gap-2">
              <DollarSign className="size-4 text-muted-foreground" />
              <span className="font-semibold">${deal.value.toLocaleString()}</span>
              {deal.probability && (
                <Badge variant="outline" className="ml-auto text-xs">
                  {deal.probability}%
                </Badge>
              )}
            </div>
          )}

          {deal.leads && (
            <div className="flex items-center gap-2 text-sm">
              <User className="size-4 text-muted-foreground" />
              <span className="text-muted-foreground">{deal.leads.name}</span>
            </div>
          )}

          {deal.properties && (
            <div className="flex items-center gap-2 text-sm">
              <Home className="size-4 text-muted-foreground" />
              <span className="truncate text-muted-foreground">{deal.properties.address}</span>
            </div>
          )}

          {deal.expected_close_date && (
            <div className="flex items-center gap-2 text-sm">
              <Calendar className="size-4 text-muted-foreground" />
              <span className="text-muted-foreground">
                {formatDistanceToNow(new Date(deal.expected_close_date), { addSuffix: true })}
              </span>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Deal</DialogTitle>
            <DialogDescription>Update the deal information below.</DialogDescription>
          </DialogHeader>
          <EditDealForm deal={deal} onSuccess={() => setShowEditDialog(false)} />
        </DialogContent>
      </Dialog>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the deal "{deal.title}". This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
