"use client"

import { useState, useEffect } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { createDeal } from "@/app/actions/deals"
import { Spinner } from "@/components/ui/spinner"
import { useRouter } from "next/navigation"
import { createBrowserClient } from "@/lib/supabase/client"

const dealSchema = z.object({
  title: z.string().min(1, "Title is required"),
  lead_id: z.string().uuid("Please select a lead"),
  property_id: z.string().uuid("Please select a property").optional().or(z.literal("")),
  stage: z.enum(["lead", "qualified", "proposal", "negotiation", "closed_won", "closed_lost"]),
  value: z.string().optional(),
  probability: z.string().optional(),
  expected_close_date: z.string().optional(),
  notes: z.string().optional(),
})

type DealFormData = z.infer<typeof dealSchema>

export function CreateDealForm({ onSuccess }: { onSuccess: () => void }) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [leads, setLeads] = useState<Array<{ id: string; name: string }>>([])
  const [properties, setProperties] = useState<Array<{ id: string; address: string }>>([])
  const router = useRouter()
  const supabase = createBrowserClient()

  useEffect(() => {
    async function fetchData() {
      const [leadsResult, propertiesResult] = await Promise.all([
        supabase.from("leads").select("id, name").order("name"),
        supabase.from("properties").select("id, address").order("address"),
      ])

      if (leadsResult.data) setLeads(leadsResult.data)
      if (propertiesResult.data) setProperties(propertiesResult.data)
    }
    fetchData()
  }, [supabase])

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm<DealFormData>({
    resolver: zodResolver(dealSchema),
    defaultValues: {
      stage: "lead",
    },
  })

  const onSubmit = async (data: DealFormData) => {
    setIsSubmitting(true)
    try {
      const dealData = {
        ...data,
        property_id: data.property_id || null,
        value: data.value ? Number.parseFloat(data.value) : null,
        probability: data.probability ? Number.parseInt(data.probability) : null,
        expected_close_date: data.expected_close_date || null,
      }
      await createDeal(dealData)
      router.refresh()
      onSuccess()
    } catch (error) {
      console.error("Failed to create deal:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2 sm:col-span-2">
          <Label htmlFor="title">
            Deal Title <span className="text-destructive">*</span>
          </Label>
          <Input id="title" {...register("title")} placeholder="Property sale - 123 Main St" />
          {errors.title && <p className="text-destructive text-sm">{errors.title.message}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="lead_id">
            Lead <span className="text-destructive">*</span>
          </Label>
          <Select onValueChange={(value) => setValue("lead_id", value)}>
            <SelectTrigger id="lead_id">
              <SelectValue placeholder="Select a lead" />
            </SelectTrigger>
            <SelectContent>
              {leads.map((lead) => (
                <SelectItem key={lead.id} value={lead.id}>
                  {lead.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {errors.lead_id && <p className="text-destructive text-sm">{errors.lead_id.message}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="property_id">Property</Label>
          <Select onValueChange={(value) => setValue("property_id", value)}>
            <SelectTrigger id="property_id">
              <SelectValue placeholder="Select a property" />
            </SelectTrigger>
            <SelectContent>
              {properties.map((property) => (
                <SelectItem key={property.id} value={property.id}>
                  {property.address}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="stage">
            Stage <span className="text-destructive">*</span>
          </Label>
          <Select defaultValue="lead" onValueChange={(value) => setValue("stage", value as any)}>
            <SelectTrigger id="stage">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="lead">Lead</SelectItem>
              <SelectItem value="qualified">Qualified</SelectItem>
              <SelectItem value="proposal">Proposal</SelectItem>
              <SelectItem value="negotiation">Negotiation</SelectItem>
              <SelectItem value="closed_won">Closed Won</SelectItem>
              <SelectItem value="closed_lost">Closed Lost</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="value">Deal Value</Label>
          <Input id="value" type="number" {...register("value")} placeholder="250000" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="probability">Probability (%)</Label>
          <Input id="probability" type="number" min="0" max="100" {...register("probability")} placeholder="75" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="expected_close_date">Expected Close Date</Label>
          <Input id="expected_close_date" type="date" {...register("expected_close_date")} />
        </div>

        <div className="space-y-2 sm:col-span-2">
          <Label htmlFor="notes">Notes</Label>
          <Textarea id="notes" {...register("notes")} placeholder="Additional information about the deal..." rows={4} />
        </div>
      </div>

      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={onSuccess} disabled={isSubmitting}>
          Cancel
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting && <Spinner />}
          Create Deal
        </Button>
      </div>
    </form>
  )
}
