import { Card, CardContent } from "@/components/ui/card"
import { createServerClient } from "@/lib/supabase/server"
import { TrendingUp, Target, DollarSign, Percent } from "lucide-react"

export async function PipelineStats() {
  const supabase = await createServerClient()

  const { data: deals } = await supabase.from("deals").select("value, stage, probability")

  const dealsList = deals || []

  const totalValue = dealsList.reduce((sum, deal) => sum + (deal.value || 0), 0)
  const activeDeals = dealsList.filter((d) => d.stage !== "closed_won" && d.stage !== "closed_lost").length
  const wonDeals = dealsList.filter((d) => d.stage === "closed_won")
  const wonValue = wonDeals.reduce((sum, deal) => sum + (deal.value || 0), 0)
  const winRate = dealsList.length > 0 ? ((wonDeals.length / dealsList.length) * 100).toFixed(1) : "0"

  const stats = [
    {
      label: "Total Pipeline Value",
      value: `$${(totalValue / 1000).toFixed(0)}k`,
      icon: DollarSign,
    },
    {
      label: "Active Deals",
      value: activeDeals,
      icon: Target,
    },
    {
      label: "Won This Month",
      value: `$${(wonValue / 1000).toFixed(0)}k`,
      icon: TrendingUp,
    },
    {
      label: "Win Rate",
      value: `${winRate}%`,
      icon: Percent,
    },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => {
        const Icon = stat.icon
        return (
          <Card key={stat.label}>
            <CardContent className="flex items-center gap-4 p-6">
              <div className="bg-primary/10 text-primary flex size-12 items-center justify-center rounded-lg">
                <Icon className="size-6" />
              </div>
              <div className="flex flex-col">
                <span className="text-muted-foreground text-sm">{stat.label}</span>
                <span className="text-2xl font-bold">{stat.value}</span>
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
