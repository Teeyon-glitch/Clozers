"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday } from "date-fns"

// Mock events data - in production, this would come from the database
const mockEvents = [
  {
    id: 1,
    title: "Property Viewing - 123 Main St",
    date: new Date(2025, 0, 20, 10, 0),
    type: "viewing",
  },
  {
    id: 2,
    title: "Client Meeting - John Smith",
    date: new Date(2025, 0, 20, 14, 0),
    type: "meeting",
  },
  {
    id: 3,
    title: "Property Inspection",
    date: new Date(2025, 0, 22, 9, 0),
    type: "inspection",
  },
  {
    id: 4,
    title: "Contract Signing",
    date: new Date(2025, 0, 24, 15, 0),
    type: "appointment",
  },
]

export function CalendarView() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date())

  const daysInMonth = eachDayOfInterval({
    start: startOfMonth(currentMonth),
    end: endOfMonth(currentMonth),
  })

  const eventsOnSelectedDate = mockEvents.filter((event) => isSameDay(event.date, selectedDate))

  const previousMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1))
  }

  const nextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1))
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>{format(currentMonth, "MMMM yyyy")}</CardTitle>
          <div className="flex gap-2">
            <Button variant="outline" size="icon-sm" onClick={previousMonth}>
              <ChevronLeft className="size-4" />
            </Button>
            <Button variant="outline" size="icon-sm" onClick={nextMonth}>
              <ChevronRight className="size-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <Calendar mode="single" selected={selectedDate} onSelect={(date) => date && setSelectedDate(date)} />

        <div className="space-y-3">
          <h3 className="font-semibold">
            Events on {format(selectedDate, "MMMM d, yyyy")}
            {isToday(selectedDate) && <span className="text-primary ml-2 text-sm font-normal">(Today)</span>}
          </h3>

          {eventsOnSelectedDate.length === 0 ? (
            <p className="text-muted-foreground text-sm">No events scheduled for this day</p>
          ) : (
            <div className="space-y-2">
              {eventsOnSelectedDate.map((event) => (
                <div key={event.id} className="flex items-start gap-3 rounded-lg border p-3">
                  <div className="bg-primary/10 text-primary flex size-10 shrink-0 items-center justify-center rounded-lg text-sm font-semibold">
                    {format(event.date, "HH:mm")}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{event.title}</p>
                    <p className="text-muted-foreground text-sm capitalize">{event.type}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
