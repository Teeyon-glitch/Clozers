import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Clock, MapPin, User, MoreHorizontal } from "lucide-react"
import { format, formatDistanceToNow } from "date-fns"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

// Mock events data - in production, this would come from the database
const upcomingEvents = [
  {
    id: 1,
    title: "Property Viewing",
    description: "123 Main Street, San Francisco",
    date: new Date(2025, 0, 20, 10, 0),
    type: "viewing",
    attendee: "John Smith",
  },
  {
    id: 2,
    title: "Client Meeting",
    description: "Discuss investment opportunities",
    date: new Date(2025, 0, 20, 14, 0),
    type: "meeting",
    attendee: "Sarah Johnson",
  },
  {
    id: 3,
    title: "Property Inspection",
    description: "456 Oak Avenue, Oakland",
    date: new Date(2025, 0, 22, 9, 0),
    type: "inspection",
    attendee: "Mike Davis",
  },
  {
    id: 4,
    title: "Contract Signing",
    description: "Final paperwork for 789 Pine St",
    date: new Date(2025, 0, 24, 15, 0),
    type: "appointment",
    attendee: "Emily Brown",
  },
  {
    id: 5,
    title: "Open House",
    description: "321 Elm Street, Berkeley",
    date: new Date(2025, 0, 25, 13, 0),
    type: "viewing",
    attendee: "Multiple attendees",
  },
]

const typeColors = {
  viewing: "default",
  meeting: "secondary",
  inspection: "outline",
  appointment: "default",
} as const

export function UpcomingEvents() {
  return (
    <Card className="h-fit">
      <CardHeader>
        <CardTitle>Upcoming Events</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {upcomingEvents.map((event) => (
            <div key={event.id} className="flex gap-3 rounded-lg border p-3">
              <div className="bg-primary/10 text-primary flex size-12 shrink-0 flex-col items-center justify-center rounded-lg">
                <span className="text-xs font-medium">{format(event.date, "MMM")}</span>
                <span className="text-lg font-bold">{format(event.date, "d")}</span>
              </div>

              <div className="flex-1 space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-medium">{event.title}</p>
                    <Badge variant={typeColors[event.type as keyof typeof typeColors]} className="mt-1 text-xs">
                      {event.type}
                    </Badge>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon-sm">
                        <MoreHorizontal className="size-4" />
                        <span className="sr-only">Open menu</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuItem>View details</DropdownMenuItem>
                      <DropdownMenuItem>Edit event</DropdownMenuItem>
                      <DropdownMenuItem>Reschedule</DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-destructive">Cancel event</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="space-y-1 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1.5">
                    <Clock className="size-3" />
                    <span>{format(event.date, "h:mm a")}</span>
                    <span className="text-xs">({formatDistanceToNow(event.date, { addSuffix: true })})</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <MapPin className="size-3" />
                    <span className="line-clamp-1">{event.description}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <User className="size-3" />
                    <span>{event.attendee}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
