"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Spinner } from "@/components/ui/spinner"
import { useRouter } from "next/navigation"

const eventSchema = z.object({
  title: z.string().min(1, "Title is required"),
  type: z.enum(["viewing", "meeting", "inspection", "appointment", "other"]),
  date: z.string().min(1, "Date is required"),
  time: z.string().min(1, "Time is required"),
  duration: z.string().optional(),
  location: z.string().optional(),
  attendees: z.string().optional(),
  notes: z.string().optional(),
})

type EventFormData = z.infer<typeof eventSchema>

export function CreateEventForm({ onSuccess }: { onSuccess: () => void }) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const router = useRouter()

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm<EventFormData>({
    resolver: zodResolver(eventSchema),
    defaultValues: {
      type: "meeting",
      duration: "60",
    },
  })

  const onSubmit = async (data: EventFormData) => {
    setIsSubmitting(true)
    try {
      // In production, this would call a server action to create the event
      console.log("Creating event:", data)
      await new Promise((resolve) => setTimeout(resolve, 1000))
      router.refresh()
      onSuccess()
    } catch (error) {
      console.error("Failed to create event:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2 sm:col-span-2">
          <Label htmlFor="title">
            Event Title <span className="text-destructive">*</span>
          </Label>
          <Input id="title" {...register("title")} placeholder="Property viewing with client" />
          {errors.title && <p className="text-destructive text-sm">{errors.title.message}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="type">
            Event Type <span className="text-destructive">*</span>
          </Label>
          <Select defaultValue="meeting" onValueChange={(value) => setValue("type", value as any)}>
            <SelectTrigger id="type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="viewing">Property Viewing</SelectItem>
              <SelectItem value="meeting">Client Meeting</SelectItem>
              <SelectItem value="inspection">Property Inspection</SelectItem>
              <SelectItem value="appointment">Appointment</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="duration">Duration (minutes)</Label>
          <Input id="duration" type="number" {...register("duration")} placeholder="60" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="date">
            Date <span className="text-destructive">*</span>
          </Label>
          <Input id="date" type="date" {...register("date")} />
          {errors.date && <p className="text-destructive text-sm">{errors.date.message}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="time">
            Time <span className="text-destructive">*</span>
          </Label>
          <Input id="time" type="time" {...register("time")} />
          {errors.time && <p className="text-destructive text-sm">{errors.time.message}</p>}
        </div>

        <div className="space-y-2 sm:col-span-2">
          <Label htmlFor="location">Location</Label>
          <Input id="location" {...register("location")} placeholder="123 Main Street, San Francisco, CA" />
        </div>

        <div className="space-y-2 sm:col-span-2">
          <Label htmlFor="attendees">Attendees</Label>
          <Input id="attendees" {...register("attendees")} placeholder="John Smith, Sarah Johnson" />
        </div>

        <div className="space-y-2 sm:col-span-2">
          <Label htmlFor="notes">Notes</Label>
          <Textarea id="notes" {...register("notes")} placeholder="Additional details about the event..." rows={4} />
        </div>
      </div>

      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={onSuccess} disabled={isSubmitting}>
          Cancel
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting && <Spinner />}
          Create Event
        </Button>
      </div>
    </form>
  )
}
