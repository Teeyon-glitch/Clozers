import { createServerClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, MapPin, User } from "lucide-react"
import { format } from "date-fns"

export async function UpcomingEventsList() {
  const supabase = await createServerClient()

  const { data: activities } = await supabase
    .from("activities")
    .select(`
      *,
      leads (
        first_name,
        last_name,
        email
      )
    `)
    .in("type", ["viewing", "meeting", "appointment"])
    .gte("scheduled_at", new Date().toISOString())
    .order("scheduled_at", { ascending: true })
    .limit(20)

  if (!activities || activities.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>No Upcoming Events</CardTitle>
          <CardDescription>You don't have any scheduled events at the moment.</CardDescription>
        </CardHeader>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {activities.map((activity) => {
        const scheduledDate = new Date(activity.scheduled_at)
        const lead = activity.leads

        return (
          <Card key={activity.id}>
            <CardContent className="flex items-start gap-4 p-6">
              <div className="flex flex-col items-center justify-center rounded-lg bg-primary/10 p-3 text-primary">
                <span className="text-2xl font-bold">{format(scheduledDate, "d")}</span>
                <span className="text-xs uppercase">{format(scheduledDate, "MMM")}</span>
              </div>

              <div className="flex-1 space-y-2">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-semibold text-lg">{activity.title}</h3>
                    {activity.description && <p className="text-sm text-muted-foreground">{activity.description}</p>}
                  </div>
                  <Badge
                    variant={
                      activity.type === "viewing" ? "default" : activity.type === "meeting" ? "secondary" : "outline"
                    }
                  >
                    {activity.type}
                  </Badge>
                </div>

                <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Clock className="size-4" />
                    {format(scheduledDate, "h:mm a")}
                  </div>

                  {activity.location && (
                    <div className="flex items-center gap-1">
                      <MapPin className="size-4" />
                      {activity.location}
                    </div>
                  )}

                  {lead && (
                    <div className="flex items-center gap-1">
                      <User className="size-4" />
                      {lead.first_name} {lead.last_name}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
