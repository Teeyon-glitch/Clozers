import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { createServerClient } from "@/lib/supabase/server"
import { Bed, Bath, Square, MapPin } from "lucide-react"
import { PropertyActions } from "./property-actions"

const statusColors = {
  available: "default",
  under_contract: "secondary",
  sold: "outline",
  off_market: "outline",
} as const

const typeColors = {
  residential: "default",
  commercial: "secondary",
  land: "outline",
  rental: "default",
} as const

interface PropertiesGridProps {
  searchParams?: {
    search?: string
    type?: string
    priceRange?: string
    status?: string
  }
}

export async function PropertiesGrid({ searchParams }: PropertiesGridProps) {
  const supabase = await createServerClient()

  let query = supabase.from("properties").select("*")

  // Apply search filter
  if (searchParams?.search) {
    query = query.or(
      `address.ilike.%${searchParams.search}%,city.ilike.%${searchParams.search}%,zip_code.ilike.%${searchParams.search}%`,
    )
  }

  // Apply status filter
  if (searchParams?.status && searchParams.status !== "all") {
    query = query.eq("status", searchParams.status)
  }

  // Apply type filter
  if (searchParams?.type && searchParams.type !== "all") {
    query = query.eq("type", searchParams.type)
  }

  // Apply price range filter
  if (searchParams?.priceRange && searchParams.priceRange !== "all") {
    const [min, max] = searchParams.priceRange.split("-")
    if (max === "+") {
      query = query.gte("price", Number.parseInt(min))
    } else {
      query = query.gte("price", Number.parseInt(min)).lte("price", Number.parseInt(max))
    }
  }

  const { data: properties } = await query.order("created_at", { ascending: false })

  const propertiesList = properties || []

  if (propertiesList.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-lg border border-dashed py-16">
        <p className="text-sm text-muted-foreground">No properties found. Create your first property to get started.</p>
      </div>
    )
  }

  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {propertiesList.map((property) => (
        <Card key={property.id} className="overflow-hidden transition-shadow hover:shadow-lg">
          <div className="relative aspect-video w-full overflow-hidden bg-muted">
            <img
              src={`/placeholder.jpg?height=300&width=400&query=${encodeURIComponent(property.address)}`}
              alt={property.address}
              className="size-full object-cover"
            />
            <div className="absolute right-2 top-2">
              <PropertyActions property={property} />
            </div>
          </div>

          <CardHeader className="pb-3">
            <div className="flex items-start justify-between gap-2">
              <div className="flex flex-col gap-1">
                <div className="text-2xl font-bold">${property.price?.toLocaleString()}</div>
                <div className="flex items-center gap-2">
                  <Badge variant={statusColors[property.status as keyof typeof statusColors] || "default"}>
                    {property.status?.replace("_", " ")}
                  </Badge>
                  <Badge variant={typeColors[property.type as keyof typeof typeColors] || "outline"}>
                    {property.type}
                  </Badge>
                </div>
              </div>
            </div>
          </CardHeader>

          <CardContent className="space-y-3">
            <div className="flex items-start gap-2">
              <MapPin className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
              <span className="text-sm">{property.address}</span>
            </div>

            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              {property.bedrooms && (
                <div className="flex items-center gap-1.5">
                  <Bed className="size-4" />
                  <span>{property.bedrooms} bed</span>
                </div>
              )}
              {property.bathrooms && (
                <div className="flex items-center gap-1.5">
                  <Bath className="size-4" />
                  <span>{property.bathrooms} bath</span>
                </div>
              )}
              {property.square_feet && (
                <div className="flex items-center gap-1.5">
                  <Square className="size-4" />
                  <span>{property.square_feet.toLocaleString()} sqft</span>
                </div>
              )}
            </div>

            {property.description && (
              <p className="line-clamp-2 text-sm text-muted-foreground">{property.description}</p>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
