"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { createProperty } from "@/app/actions/properties"
import { Spinner } from "@/components/ui/spinner"
import { useRouter } from "next/navigation"

const propertySchema = z.object({
  address: z.string().min(1, "Address is required"),
  city: z.string().min(1, "City is required"),
  state: z.string().min(1, "State is required"),
  zip_code: z.string().min(1, "Zip code is required"),
  type: z.enum(["residential", "commercial", "land", "rental"]),
  status: z.enum(["available", "under_contract", "sold", "off_market"]),
  price: z.string().min(1, "Price is required"),
  bedrooms: z.string().optional(),
  bathrooms: z.string().optional(),
  square_feet: z.string().optional(),
  lot_size: z.string().optional(),
  year_built: z.string().optional(),
  description: z.string().optional(),
})

type PropertyFormData = z.infer<typeof propertySchema>

export function CreatePropertyForm({ onSuccess }: { onSuccess: () => void }) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const router = useRouter()

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm<PropertyFormData>({
    resolver: zodResolver(propertySchema),
    defaultValues: {
      type: "residential",
      status: "available",
    },
  })

  const onSubmit = async (data: PropertyFormData) => {
    setIsSubmitting(true)
    try {
      const propertyData = {
        ...data,
        price: Number.parseFloat(data.price),
        bedrooms: data.bedrooms ? Number.parseInt(data.bedrooms) : null,
        bathrooms: data.bathrooms ? Number.parseFloat(data.bathrooms) : null,
        square_feet: data.square_feet ? Number.parseInt(data.square_feet) : null,
        lot_size: data.lot_size ? Number.parseFloat(data.lot_size) : null,
        year_built: data.year_built ? Number.parseInt(data.year_built) : null,
      }
      await createProperty(propertyData)
      router.refresh()
      onSuccess()
    } catch (error) {
      console.error("Failed to create property:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2 sm:col-span-2">
          <Label htmlFor="address">
            Address <span className="text-destructive">*</span>
          </Label>
          <Input id="address" {...register("address")} placeholder="123 Main Street" />
          {errors.address && <p className="text-destructive text-sm">{errors.address.message}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="city">
            City <span className="text-destructive">*</span>
          </Label>
          <Input id="city" {...register("city")} placeholder="San Francisco" />
          {errors.city && <p className="text-destructive text-sm">{errors.city.message}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="state">
            State <span className="text-destructive">*</span>
          </Label>
          <Input id="state" {...register("state")} placeholder="CA" />
          {errors.state && <p className="text-destructive text-sm">{errors.state.message}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="zip_code">
            Zip Code <span className="text-destructive">*</span>
          </Label>
          <Input id="zip_code" {...register("zip_code")} placeholder="94102" />
          {errors.zip_code && <p className="text-destructive text-sm">{errors.zip_code.message}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="type">
            Property Type <span className="text-destructive">*</span>
          </Label>
          <Select defaultValue="residential" onValueChange={(value) => setValue("type", value as any)}>
            <SelectTrigger id="type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="residential">Residential</SelectItem>
              <SelectItem value="commercial">Commercial</SelectItem>
              <SelectItem value="land">Land</SelectItem>
              <SelectItem value="rental">Rental</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="status">
            Status <span className="text-destructive">*</span>
          </Label>
          <Select defaultValue="available" onValueChange={(value) => setValue("status", value as any)}>
            <SelectTrigger id="status">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="available">Available</SelectItem>
              <SelectItem value="under_contract">Under Contract</SelectItem>
              <SelectItem value="sold">Sold</SelectItem>
              <SelectItem value="off_market">Off Market</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="price">
            Price <span className="text-destructive">*</span>
          </Label>
          <Input id="price" type="number" {...register("price")} placeholder="500000" />
          {errors.price && <p className="text-destructive text-sm">{errors.price.message}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="bedrooms">Bedrooms</Label>
          <Input id="bedrooms" type="number" {...register("bedrooms")} placeholder="3" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="bathrooms">Bathrooms</Label>
          <Input id="bathrooms" type="number" step="0.5" {...register("bathrooms")} placeholder="2.5" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="square_feet">Square Feet</Label>
          <Input id="square_feet" type="number" {...register("square_feet")} placeholder="2000" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="lot_size">Lot Size (acres)</Label>
          <Input id="lot_size" type="number" step="0.01" {...register("lot_size")} placeholder="0.25" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="year_built">Year Built</Label>
          <Input id="year_built" type="number" {...register("year_built")} placeholder="2020" />
        </div>

        <div className="space-y-2 sm:col-span-2">
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            {...register("description")}
            placeholder="Beautiful property with modern amenities..."
            rows={4}
          />
        </div>
      </div>

      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={onSuccess} disabled={isSubmitting}>
          Cancel
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting && <Spinner />}
          Add Property
        </Button>
      </div>
    </form>
  )
}
