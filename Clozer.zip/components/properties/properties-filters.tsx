"use client"

import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, X } from "lucide-react"
import { useRouter, useSearchParams } from "next/navigation"
import { useState, useTransition } from "react"

interface PropertiesFiltersProps {
  currentStatus: string
}

export function PropertiesFilters({ currentStatus }: PropertiesFiltersProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [isPending, startTransition] = useTransition()

  const [search, setSearch] = useState(searchParams.get("search") || "")
  const [type, setType] = useState(searchParams.get("type") || "all")
  const [priceRange, setPriceRange] = useState(searchParams.get("priceRange") || "all")

  const updateFilters = (newSearch: string, newType: string, newPriceRange: string) => {
    const params = new URLSearchParams()
    if (newSearch) params.set("search", newSearch)
    if (newType && newType !== "all") params.set("type", newType)
    if (newPriceRange && newPriceRange !== "all") params.set("priceRange", newPriceRange)
    if (currentStatus !== "all") params.set("status", currentStatus)

    startTransition(() => {
      router.push(`/properties?${params.toString()}`)
    })
  }

  const handleSearchChange = (value: string) => {
    setSearch(value)
    updateFilters(value, type, priceRange)
  }

  const handleTypeChange = (value: string) => {
    setType(value)
    updateFilters(search, value, priceRange)
  }

  const handlePriceRangeChange = (value: string) => {
    setPriceRange(value)
    updateFilters(search, type, value)
  }

  const clearFilters = () => {
    setSearch("")
    setType("all")
    setPriceRange("all")
    startTransition(() => {
      const params = new URLSearchParams()
      if (currentStatus !== "all") params.set("status", currentStatus)
      router.push(`/properties?${params.toString()}`)
    })
  }

  const hasActiveFilters = search || (type && type !== "all") || (priceRange && priceRange !== "all")

  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search by address, city, or zip..."
          className="pl-9"
          value={search}
          onChange={(e) => handleSearchChange(e.target.value)}
        />
      </div>

      <div className="flex gap-2">
        <Select value={type} onValueChange={handleTypeChange}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Property Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="residential">Residential</SelectItem>
            <SelectItem value="commercial">Commercial</SelectItem>
            <SelectItem value="land">Land</SelectItem>
            <SelectItem value="rental">Rental</SelectItem>
          </SelectContent>
        </Select>

        <Select value={priceRange} onValueChange={handlePriceRangeChange}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Price Range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Prices</SelectItem>
            <SelectItem value="0-200000">Under $200k</SelectItem>
            <SelectItem value="200000-500000">$200k - $500k</SelectItem>
            <SelectItem value="500000-1000000">$500k - $1M</SelectItem>
            <SelectItem value="1000000-+">$1M+</SelectItem>
          </SelectContent>
        </Select>

        {hasActiveFilters && (
          <Button variant="outline" size="icon" onClick={clearFilters} disabled={isPending}>
            <X className="size-4" />
            <span className="sr-only">Clear filters</span>
          </Button>
        )}
      </div>
    </div>
  )
}
