"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Plus, MoreHorizontal, Mail, Eye } from "lucide-react"
import { CreateTemplateDialog } from "./create-template-dialog"

const templates = [
  {
    id: 1,
    name: "Welcome Email",
    subject: "Welcome to [Company Name]",
    category: "onboarding",
    description: "Initial welcome email for new leads",
    lastUsed: "2 days ago",
  },
  {
    id: 2,
    name: "Property Viewing Confirmation",
    subject: "Your Property Viewing is Confirmed",
    category: "scheduling",
    description: "Confirmation email for scheduled property viewings",
    lastUsed: "1 day ago",
  },
  {
    id: 3,
    name: "Follow-up After Viewing",
    subject: "Thank you for viewing [Property Address]",
    category: "follow-up",
    description: "Follow-up email after property viewing",
    lastUsed: "3 hours ago",
  },
  {
    id: 4,
    name: "Offer Submitted",
    subject: "Your Offer Has Been Submitted",
    category: "transaction",
    description: "Notification when an offer is submitted",
    lastUsed: "5 days ago",
  },
  {
    id: 5,
    name: "Monthly Market Update",
    subject: "Your Monthly Real Estate Market Update",
    category: "newsletter",
    description: "Monthly newsletter with market insights",
    lastUsed: "1 week ago",
  },
  {
    id: 6,
    name: "Contract Reminder",
    subject: "Important: Contract Deadline Approaching",
    category: "reminder",
    description: "Reminder for upcoming contract deadlines",
    lastUsed: "Yesterday",
  },
]

const categoryColors = {
  onboarding: "default",
  scheduling: "secondary",
  "follow-up": "outline",
  transaction: "default",
  newsletter: "secondary",
  reminder: "outline",
} as const

export function EmailTemplates() {
  const [createDialogOpen, setCreateDialogOpen] = useState(false)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">Email Templates</h2>
          <p className="text-muted-foreground text-sm">Create and manage reusable email templates</p>
        </div>
        <Button onClick={() => setCreateDialogOpen(true)}>
          <Plus className="size-4" />
          Create Template
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {templates.map((template) => (
          <Card key={template.id} className="transition-shadow hover:shadow-md">
            <CardHeader>
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 space-y-1">
                  <CardTitle className="text-base">{template.name}</CardTitle>
                  <Badge variant={categoryColors[template.category as keyof typeof categoryColors]}>
                    {template.category}
                  </Badge>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon-sm">
                      <MoreHorizontal className="size-4" />
                      <span className="sr-only">Open menu</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                    <DropdownMenuItem>
                      <Eye className="size-4" />
                      Preview
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Mail className="size-4" />
                      Use template
                    </DropdownMenuItem>
                    <DropdownMenuItem>Edit</DropdownMenuItem>
                    <DropdownMenuItem>Duplicate</DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="text-muted-foreground text-sm font-medium">Subject:</p>
                <p className="text-sm">{template.subject}</p>
              </div>
              <CardDescription>{template.description}</CardDescription>
              <p className="text-muted-foreground text-xs">Last used: {template.lastUsed}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <CreateTemplateDialog open={createDialogOpen} onOpenChange={setCreateDialogOpen} />
    </div>
  )
}
