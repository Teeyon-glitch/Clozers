"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Plus, MoreHorizontal, Zap, Clock, Bell } from "lucide-react"
import { CreateWorkflowDialog } from "./create-workflow-dialog"

const workflows = [
  {
    id: 1,
    name: "New Lead Welcome Sequence",
    description: "Automatically send welcome email and schedule follow-up when a new lead is created",
    trigger: "New lead created",
    actions: ["Send welcome email", "Create follow-up task (3 days)"],
    active: true,
    runsCount: 145,
  },
  {
    id: 2,
    name: "Property Viewing Reminder",
    description: "Send reminder email 24 hours before scheduled property viewing",
    trigger: "24 hours before viewing",
    actions: ["Send reminder email", "Send SMS notification"],
    active: true,
    runsCount: 89,
  },
  {
    id: 3,
    name: "Deal Stage Change Notification",
    description: "Notify team when a deal moves to negotiation stage",
    trigger: "Deal stage = Negotiation",
    actions: ["Send team notification", "Create approval task"],
    active: true,
    runsCount: 34,
  },
  {
    id: 4,
    name: "Inactive Lead Re-engagement",
    description: "Automatically reach out to leads with no activity in 30 days",
    trigger: "No activity for 30 days",
    actions: ["Send re-engagement email", "Assign to sales rep"],
    active: false,
    runsCount: 12,
  },
  {
    id: 5,
    name: "Contract Deadline Alert",
    description: "Alert team 7 days before contract deadline",
    trigger: "7 days before deadline",
    actions: ["Send alert email", "Create urgent task"],
    active: true,
    runsCount: 56,
  },
]

export function AutomationWorkflows() {
  const [createDialogOpen, setCreateDialogOpen] = useState(false)
  const [workflowStates, setWorkflowStates] = useState<Record<number, boolean>>(
    workflows.reduce(
      (acc, workflow) => {
        acc[workflow.id] = workflow.active
        return acc
      },
      {} as Record<number, boolean>,
    ),
  )

  const toggleWorkflow = (id: number) => {
    setWorkflowStates((prev) => ({
      ...prev,
      [id]: !prev[id],
    }))
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">Automation Workflows</h2>
          <p className="text-muted-foreground text-sm">Set up automated workflows to streamline your processes</p>
        </div>
        <Button onClick={() => setCreateDialogOpen(true)}>
          <Plus className="size-4" />
          Create Workflow
        </Button>
      </div>

      <div className="space-y-4">
        {workflows.map((workflow) => (
          <Card key={workflow.id}>
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-3">
                    <CardTitle className="text-base">{workflow.name}</CardTitle>
                    <Badge variant={workflowStates[workflow.id] ? "default" : "secondary"}>
                      {workflowStates[workflow.id] ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                  <CardDescription>{workflow.description}</CardDescription>
                </div>

                <div className="flex items-center gap-2">
                  <Switch checked={workflowStates[workflow.id]} onCheckedChange={() => toggleWorkflow(workflow.id)} />
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon-sm">
                        <MoreHorizontal className="size-4" />
                        <span className="sr-only">Open menu</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuItem>Edit workflow</DropdownMenuItem>
                      <DropdownMenuItem>View history</DropdownMenuItem>
                      <DropdownMenuItem>Duplicate</DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <Zap className="size-4 text-muted-foreground" />
                    Trigger
                  </div>
                  <p className="text-muted-foreground text-sm">{workflow.trigger}</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <Clock className="size-4 text-muted-foreground" />
                    Total Runs
                  </div>
                  <p className="text-muted-foreground text-sm">{workflow.runsCount} times</p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <Bell className="size-4 text-muted-foreground" />
                  Actions
                </div>
                <div className="flex flex-wrap gap-2">
                  {workflow.actions.map((action, index) => (
                    <Badge key={index} variant="outline">
                      {action}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <CreateWorkflowDialog open={createDialogOpen} onOpenChange={setCreateDialogOpen} />
    </div>
  )
}
