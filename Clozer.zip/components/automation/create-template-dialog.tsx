"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Spinner } from "@/components/ui/spinner"

const templateSchema = z.object({
  name: z.string().min(1, "Name is required"),
  subject: z.string().min(1, "Subject is required"),
  category: z.enum(["onboarding", "scheduling", "follow-up", "transaction", "newsletter", "reminder"]),
  body: z.string().min(1, "Email body is required"),
})

type TemplateFormData = z.infer<typeof templateSchema>

interface CreateTemplateDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function CreateTemplateDialog({ open, onOpenChange }: CreateTemplateDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    reset,
  } = useForm<TemplateFormData>({
    resolver: zodResolver(templateSchema),
    defaultValues: {
      category: "onboarding",
    },
  })

  const onSubmit = async (data: TemplateFormData) => {
    setIsSubmitting(true)
    try {
      console.log("Creating template:", data)
      await new Promise((resolve) => setTimeout(resolve, 1000))
      reset()
      onOpenChange(false)
    } catch (error) {
      console.error("Failed to create template:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Email Template</DialogTitle>
          <DialogDescription>Create a reusable email template for your communications.</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="name">
                Template Name <span className="text-destructive">*</span>
              </Label>
              <Input id="name" {...register("name")} placeholder="Welcome Email" />
              {errors.name && <p className="text-destructive text-sm">{errors.name.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">
                Category <span className="text-destructive">*</span>
              </Label>
              <Select defaultValue="onboarding" onValueChange={(value) => setValue("category", value as any)}>
                <SelectTrigger id="category">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="onboarding">Onboarding</SelectItem>
                  <SelectItem value="scheduling">Scheduling</SelectItem>
                  <SelectItem value="follow-up">Follow-up</SelectItem>
                  <SelectItem value="transaction">Transaction</SelectItem>
                  <SelectItem value="newsletter">Newsletter</SelectItem>
                  <SelectItem value="reminder">Reminder</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="subject">
                Email Subject <span className="text-destructive">*</span>
              </Label>
              <Input id="subject" {...register("subject")} placeholder="Welcome to [Company Name]" />
              {errors.subject && <p className="text-destructive text-sm">{errors.subject.message}</p>}
            </div>

            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="body">
                Email Body <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="body"
                {...register("body")}
                placeholder="Dear [First Name],&#10;&#10;Welcome to our real estate services..."
                rows={12}
              />
              {errors.body && <p className="text-destructive text-sm">{errors.body.message}</p>}
              <p className="text-muted-foreground text-xs">
                Use variables like [First Name], [Last Name], [Property Address], [Company Name]
              </p>
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Spinner />}
              Create Template
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
