"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Spinner } from "@/components/ui/spinner"

const workflowSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().min(1, "Description is required"),
  trigger: z.enum(["new_lead", "deal_stage_change", "time_based", "property_status", "activity"]),
  action: z.enum(["send_email", "create_task", "send_notification", "update_field", "assign_user"]),
})

type WorkflowFormData = z.infer<typeof workflowSchema>

interface CreateWorkflowDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function CreateWorkflowDialog({ open, onOpenChange }: CreateWorkflowDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    reset,
  } = useForm<WorkflowFormData>({
    resolver: zodResolver(workflowSchema),
    defaultValues: {
      trigger: "new_lead",
      action: "send_email",
    },
  })

  const onSubmit = async (data: WorkflowFormData) => {
    setIsSubmitting(true)
    try {
      console.log("Creating workflow:", data)
      await new Promise((resolve) => setTimeout(resolve, 1000))
      reset()
      onOpenChange(false)
    } catch (error) {
      console.error("Failed to create workflow:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Create Automation Workflow</DialogTitle>
          <DialogDescription>Set up an automated workflow to streamline your processes.</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">
                Workflow Name <span className="text-destructive">*</span>
              </Label>
              <Input id="name" {...register("name")} placeholder="New Lead Welcome Sequence" />
              {errors.name && <p className="text-destructive text-sm">{errors.name.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">
                Description <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="description"
                {...register("description")}
                placeholder="Describe what this workflow does..."
                rows={3}
              />
              {errors.description && <p className="text-destructive text-sm">{errors.description.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="trigger">
                Trigger <span className="text-destructive">*</span>
              </Label>
              <Select defaultValue="new_lead" onValueChange={(value) => setValue("trigger", value as any)}>
                <SelectTrigger id="trigger">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="new_lead">New Lead Created</SelectItem>
                  <SelectItem value="deal_stage_change">Deal Stage Changed</SelectItem>
                  <SelectItem value="time_based">Time-Based (Schedule)</SelectItem>
                  <SelectItem value="property_status">Property Status Changed</SelectItem>
                  <SelectItem value="activity">Activity Logged</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="action">
                Action <span className="text-destructive">*</span>
              </Label>
              <Select defaultValue="send_email" onValueChange={(value) => setValue("action", value as any)}>
                <SelectTrigger id="action">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="send_email">Send Email</SelectItem>
                  <SelectItem value="create_task">Create Task</SelectItem>
                  <SelectItem value="send_notification">Send Notification</SelectItem>
                  <SelectItem value="update_field">Update Field</SelectItem>
                  <SelectItem value="assign_user">Assign to User</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Spinner />}
              Create Workflow
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
