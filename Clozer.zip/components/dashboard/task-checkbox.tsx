"use client"

import { Checkbox } from "@/components/ui/checkbox"
import { useRouter } from "next/navigation"
import { useState } from "react"

interface TaskCheckboxProps {
  taskId: number
  completed: boolean
}

export function TaskCheckbox({ taskId, completed }: TaskCheckboxProps) {
  const router = useRouter()
  const [isUpdating, setIsUpdating] = useState(false)

  const handleCheckedChange = async (checked: boolean) => {
    setIsUpdating(true)
    try {
      const response = await fetch("/api/tasks/update", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ taskId, completed: checked }),
      })

      if (response.ok) {
        router.refresh()
      }
    } catch (error) {
      console.error("Failed to update task:", error)
    } finally {
      setIsUpdating(false)
    }
  }

  return (
    <Checkbox
      id={`task-${taskId}`}
      checked={completed}
      onCheckedChange={handleCheckedChange}
      disabled={isUpdating}
      className="mt-1"
    />
  )
}
