import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { createServerClient } from "@/lib/supabase/server"
import { TrendingUp, Users, Home, DollarSign, ArrowUpRight, ArrowDownRight, AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export async function DashboardStats() {
  const supabase = await createServerClient()

  const [leadsResult, propertiesResult, dealsResult] = await Promise.all([
    supabase.from("leads").select("status", { count: "exact" }),
    supabase.from("properties").select("status", { count: "exact" }),
    supabase.from("deals").select("value, status").eq("status", "closed_won"),
  ])

  // Check if tables exist
  const tablesExist = !leadsResult.error && !propertiesResult.error && !dealsResult.error

  if (!tablesExist) {
    return (
      <Alert>
        <AlertCircle className="size-4" />
        <AlertTitle>Database Setup Required</AlertTitle>
        <AlertDescription>
          Your database tables haven't been created yet. Please execute the SQL scripts in the{" "}
          <code className="rounded bg-muted px-1 py-0.5 text-sm">scripts</code> folder to set up your CRM database. Run
          scripts 01 through 06 in order.
        </AlertDescription>
      </Alert>
    )
  }

  const totalLeads = leadsResult.count || 0
  const activeLeads = leadsResult.data?.filter((l) => l.status === "new" || l.status === "contacted").length || 0
  const totalProperties = propertiesResult.count || 0
  const activeProperties = propertiesResult.data?.filter((p) => p.status === "available").length || 0
  const totalRevenue = dealsResult.data?.reduce((sum, deal) => sum + (deal.value || 0), 0) || 0

  const stats = [
    {
      title: "Total Leads",
      value: totalLeads,
      change: "+12.5%",
      trend: "up" as const,
      icon: Users,
      description: `${activeLeads} active`,
    },
    {
      title: "Properties",
      value: totalProperties,
      change: "+8.2%",
      trend: "up" as const,
      icon: Home,
      description: `${activeProperties} available`,
    },
    {
      title: "Revenue",
      value: `$${(totalRevenue / 1000).toFixed(1)}k`,
      change: "+23.1%",
      trend: "up" as const,
      icon: DollarSign,
      description: "This month",
    },
    {
      title: "Conversion Rate",
      value: "24.5%",
      change: "-2.3%",
      trend: "down" as const,
      icon: TrendingUp,
      description: "Last 30 days",
    },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => {
        const Icon = stat.icon
        const TrendIcon = stat.trend === "up" ? ArrowUpRight : ArrowDownRight
        return (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
              <Icon className="size-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="space-y-1">
              <div className="text-2xl font-bold">{stat.value}</div>
              <div className="flex items-center gap-2 text-xs">
                <span
                  className={`flex items-center gap-1 font-medium ${
                    stat.trend === "up" ? "text-emerald-600" : "text-red-600"
                  }`}
                >
                  <TrendIcon className="size-3" />
                  {stat.change}
                </span>
                <span className="text-muted-foreground">{stat.description}</span>
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
