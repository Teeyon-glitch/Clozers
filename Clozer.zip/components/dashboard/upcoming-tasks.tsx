import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "lucide-react"
import { format } from "date-fns"
import { createServerClient } from "@/lib/supabase/server"
import { TaskCheckbox } from "./task-checkbox"

export async function UpcomingTasks() {
  const supabase = await createServerClient()

  // Fetch upcoming tasks
  const { data: tasks } = await supabase
    .from("tasks")
    .select("*")
    .eq("completed", false)
    .order("due_date", { ascending: true })
    .limit(5)

  const taskList = tasks || []

  return (
    <Card>
      <CardHeader>
        <CardTitle>Upcoming Tasks</CardTitle>
      </CardHeader>
      <CardContent>
        {taskList.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <p className="text-sm text-muted-foreground">No upcoming tasks</p>
          </div>
        ) : (
          <div className="space-y-4">
            {taskList.map((task) => {
              const priorityColors = {
                high: "destructive",
                medium: "default",
                low: "secondary",
              } as const

              return (
                <div key={task.id} className="flex items-start gap-3">
                  <TaskCheckbox taskId={task.id} completed={task.completed} />
                  <div className="flex-1 space-y-1">
                    <label htmlFor={`task-${task.id}`} className="cursor-pointer text-sm font-medium leading-none">
                      {task.title}
                    </label>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="size-3" />
                        {format(new Date(task.due_date), "MMM d, yyyy")}
                      </div>
                      <Badge variant={priorityColors[task.priority as keyof typeof priorityColors]} className="text-xs">
                        {task.priority}
                      </Badge>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
