import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
} from "@/components/ui/chart"
import { Pie, PieChart, Cell } from "recharts"
import { createServerClient } from "@/lib/supabase/server"

const chartConfig = {
  leads: {
    label: "Leads",
  },
  website: {
    label: "Website",
    color: "hsl(var(--chart-1))",
  },
  referral: {
    label: "Referral",
    color: "hsl(var(--chart-2))",
  },
  social: {
    label: "Social Media",
    color: "hsl(var(--chart-3))",
  },
  direct: {
    label: "Direct",
    color: "hsl(var(--chart-4))",
  },
  other: {
    label: "Other",
    color: "hsl(var(--chart-5))",
  },
}

const sourceColors: Record<string, string> = {
  website: "hsl(var(--chart-1))",
  referral: "hsl(var(--chart-2))",
  "social media": "hsl(var(--chart-3))",
  direct: "hsl(var(--chart-4))",
  other: "hsl(var(--chart-5))",
}

export async function LeadSourceChart() {
  const supabase = await createServerClient()

  // Fetch leads grouped by source
  const { data: leads } = await supabase.from("leads").select("source")

  // Count leads by source
  const sourceCounts = new Map<string, number>()
  leads?.forEach((lead) => {
    const source = lead.source?.toLowerCase() || "other"
    sourceCounts.set(source, (sourceCounts.get(source) || 0) + 1)
  })

  const chartData = Array.from(sourceCounts.entries()).map(([source, count]) => ({
    source: source.charAt(0).toUpperCase() + source.slice(1),
    leads: count,
    fill: sourceColors[source] || "hsl(var(--chart-5))",
  }))

  return (
    <Card>
      <CardHeader>
        <CardTitle>Lead Sources</CardTitle>
        <CardDescription>Distribution of leads by source</CardDescription>
      </CardHeader>
      <CardContent>
        {chartData.length === 0 ? (
          <div className="flex h-64 items-center justify-center text-sm text-muted-foreground">
            No lead data available
          </div>
        ) : (
          <ChartContainer config={chartConfig} className="h-64 w-full">
            <PieChart>
              <ChartTooltip content={<ChartTooltipContent />} />
              <Pie
                data={chartData}
                dataKey="leads"
                nameKey="source"
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={2}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Pie>
              <ChartLegend content={<ChartLegendContent />} />
            </PieChart>
          </ChartContainer>
        )}
      </CardContent>
    </Card>
  )
}
