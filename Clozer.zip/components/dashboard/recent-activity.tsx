import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { createServerClient } from "@/lib/supabase/server"
import { formatDistanceToNow } from "date-fns"

export async function RecentActivity() {
  const supabase = await createServerClient()

  // Fetch recent activities
  const { data: activities } = await supabase
    .from("activities")
    .select("*, leads(name)")
    .order("created_at", { ascending: false })
    .limit(5)

  const activityList = activities || []

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        {activityList.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <p className="text-muted-foreground text-sm">No recent activity</p>
          </div>
        ) : (
          <div className="space-y-4">
            {activityList.map((activity) => {
              const initials =
                activity.leads?.name
                  ?.split(" ")
                  .map((n: string) => n[0])
                  .join("")
                  .toUpperCase() || "??"

              return (
                <div key={activity.id} className="flex items-start gap-4">
                  <Avatar className="size-9">
                    <AvatarImage src="/placeholder.svg" />
                    <AvatarFallback className="text-xs">{initials}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium">{activity.leads?.name || "Unknown"}</p>
                      <Badge variant="outline" className="text-xs">
                        {activity.type}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground text-sm">{activity.notes || "No notes"}</p>
                    <p className="text-muted-foreground text-xs">
                      {formatDistanceToNow(new Date(activity.created_at), {
                        addSuffix: true,
                      })}
                    </p>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
