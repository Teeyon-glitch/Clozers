import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, MapPin, User } from "lucide-react"
import { format, isToday, isTomorrow, parseISO } from "date-fns"

export async function UpcomingEvents() {
  const supabase = await createClient()

  const { data: events } = await supabase
    .from("activities")
    .select(`
      *,
      leads (
        first_name,
        last_name
      )
    `)
    .in("type", ["viewing", "meeting", "appointment"])
    .gte("scheduled_at", new Date().toISOString())
    .order("scheduled_at", { ascending: true })
    .limit(5)

  if (!events || events.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Upcoming Events
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">No upcoming events scheduled</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Upcoming Events
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {events.map((event) => {
          const eventDate = parseISO(event.scheduled_at)
          const dateLabel = isToday(eventDate)
            ? "Today"
            : isTomorrow(eventDate)
              ? "Tomorrow"
              : format(eventDate, "MMM d")

          return (
            <div
              key={event.id}
              className="flex flex-col gap-2 rounded-lg border p-3 hover:bg-accent/50 transition-colors"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2">
                    <Badge variant={event.type === "viewing" ? "default" : "secondary"}>{event.type}</Badge>
                    <span className="text-xs text-muted-foreground">{dateLabel}</span>
                  </div>
                  <p className="font-medium text-sm">{event.title}</p>
                </div>
              </div>

              <div className="flex flex-col gap-1 text-xs text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <Clock className="h-3 w-3" />
                  <span>{format(eventDate, "h:mm a")}</span>
                </div>

                {event.location && (
                  <div className="flex items-center gap-1.5">
                    <MapPin className="h-3 w-3" />
                    <span className="truncate">{event.location}</span>
                  </div>
                )}

                {event.leads && (
                  <div className="flex items-center gap-1.5">
                    <User className="h-3 w-3" />
                    <span>
                      {event.leads.first_name} {event.leads.last_name}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )
        })}
      </CardContent>
    </Card>
  )
}
