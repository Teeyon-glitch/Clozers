import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from "recharts"
import { createServerClient } from "@/lib/supabase/server"

const chartConfig = {
  revenue: {
    label: "Revenue",
    color: "hsl(var(--chart-1))",
  },
  deals: {
    label: "Deals",
    color: "hsl(var(--chart-2))",
  },
}

export async function RevenueChart() {
  const supabase = await createServerClient()

  // Fetch deals from the last 6 months
  const sixMonthsAgo = new Date()
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6)

  const { data: deals, error } = await supabase
    .from("deals")
    .select("value, status, closed_date")
    .eq("status", "closed_won")
    .gte("closed_date", sixMonthsAgo.toISOString())
    .order("closed_date", { ascending: true })

  // Group deals by month
  const monthlyData = new Map<string, { revenue: number; deals: number }>()

  // Initialize last 6 months
  for (let i = 5; i >= 0; i--) {
    const date = new Date()
    date.setMonth(date.getMonth() - i)
    const monthKey = date.toLocaleDateString("en-US", { month: "short" })
    monthlyData.set(monthKey, { revenue: 0, deals: 0 })
  }

  // Aggregate deals by month
  if (!error && deals) {
    deals.forEach((deal) => {
      const date = new Date(deal.closed_date)
      const monthKey = date.toLocaleDateString("en-US", { month: "short" })
      const existing = monthlyData.get(monthKey)
      if (existing) {
        existing.revenue += deal.value || 0
        existing.deals += 1
      }
    })
  }

  const chartData = Array.from(monthlyData.entries()).map(([month, data]) => ({
    month,
    revenue: data.revenue,
    deals: data.deals,
  }))

  return (
    <Card>
      <CardHeader>
        <CardTitle>Revenue Overview</CardTitle>
        <CardDescription>Monthly revenue and closed deals</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-64 w-full">
          <AreaChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={8} />
            <YAxis tickLine={false} axisLine={false} tickMargin={8} tickFormatter={(value) => `$${value / 1000}k`} />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Area
              type="monotone"
              dataKey="revenue"
              stroke="var(--color-revenue)"
              fill="var(--color-revenue)"
              fillOpacity={0.2}
              strokeWidth={2}
            />
          </AreaChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
