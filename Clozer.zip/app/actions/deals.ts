"use server"

import { createServerClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"

export async function createDeal(data: {
  title: string
  lead_id: string
  property_id?: string | null
  stage: string
  value?: number | null
  probability?: number | null
  expected_close_date?: string | null
  notes?: string
}) {
  const supabase = await createServerClient()

  const { data: deal, error } = await supabase
    .from("deals")
    .insert({
      title: data.title,
      lead_id: data.lead_id,
      property_id: data.property_id || null,
      stage: data.stage,
      value: data.value || null,
      probability: data.probability || null,
      expected_close_date: data.expected_close_date || null,
      notes: data.notes || null,
    })
    .select()
    .single()

  if (error) {
    throw new Error(error.message)
  }

  revalidatePath("/pipeline")
  return deal
}

export async function updateDeal(
  id: string,
  data: {
    title?: string
    stage?: string
    value?: number | null
    probability?: number | null
    expected_close_date?: string | null
    notes?: string
  },
) {
  const supabase = await createServerClient()

  const { data: deal, error } = await supabase.from("deals").update(data).eq("id", id).select().single()

  if (error) {
    throw new Error(error.message)
  }

  revalidatePath("/pipeline")
  return deal
}

export async function deleteDeal(id: string) {
  const supabase = await createServerClient()

  const { error } = await supabase.from("deals").delete().eq("id", id)

  if (error) {
    throw new Error(error.message)
  }

  revalidatePath("/pipeline")
}
