"use server"

import { createServerClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"

export async function createLead(data: {
  name: string
  email?: string
  phone?: string
  company?: string
  source: string
  status: string
  budget?: number | null
  notes?: string
}) {
  const supabase = await createServerClient()

  const { data: lead, error } = await supabase
    .from("leads")
    .insert({
      name: data.name,
      email: data.email || null,
      phone: data.phone || null,
      company: data.company || null,
      source: data.source,
      status: data.status,
      budget: data.budget || null,
      notes: data.notes || null,
    })
    .select()
    .single()

  if (error) {
    throw new Error(error.message)
  }

  revalidatePath("/leads")
  return lead
}

export async function updateLead(
  id: string,
  data: {
    name?: string
    email?: string
    phone?: string
    company?: string
    source?: string
    status?: string
    budget?: number | null
    notes?: string
  },
) {
  const supabase = await createServerClient()

  const { data: lead, error } = await supabase.from("leads").update(data).eq("id", id).select().single()

  if (error) {
    throw new Error(error.message)
  }

  revalidatePath("/leads")
  return lead
}

export async function deleteLead(id: string) {
  const supabase = await createServerClient()

  const { error } = await supabase.from("leads").delete().eq("id", id)

  if (error) {
    throw new Error(error.message)
  }

  revalidatePath("/leads")
}
