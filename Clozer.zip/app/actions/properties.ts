"use server"

import { createServerClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"

export async function createProperty(data: {
  address: string
  city: string
  state: string
  zip_code: string
  type: string
  status: string
  price: number
  bedrooms?: number | null
  bathrooms?: number | null
  square_feet?: number | null
  lot_size?: number | null
  year_built?: number | null
  description?: string
}) {
  const supabase = await createServerClient()

  const { data: property, error } = await supabase
    .from("properties")
    .insert({
      address: data.address,
      city: data.city,
      state: data.state,
      zip_code: data.zip_code,
      type: data.type,
      status: data.status,
      price: data.price,
      bedrooms: data.bedrooms || null,
      bathrooms: data.bathrooms || null,
      square_feet: data.square_feet || null,
      lot_size: data.lot_size || null,
      year_built: data.year_built || null,
      description: data.description || null,
    })
    .select()
    .single()

  if (error) {
    throw new Error(error.message)
  }

  revalidatePath("/properties")
  return property
}

export async function updateProperty(
  id: string,
  data: {
    address?: string
    city?: string
    state?: string
    zip_code?: string
    type?: string
    status?: string
    price?: number
    bedrooms?: number | null
    bathrooms?: number | null
    square_feet?: number | null
    lot_size?: number | null
    year_built?: number | null
    description?: string
  },
) {
  const supabase = await createServerClient()

  const { data: property, error } = await supabase.from("properties").update(data).eq("id", id).select().single()

  if (error) {
    throw new Error(error.message)
  }

  revalidatePath("/properties")
  return property
}

export async function deleteProperty(id: string) {
  const supabase = await createServerClient()

  const { error } = await supabase.from("properties").delete().eq("id", id)

  if (error) {
    throw new Error(error.message)
  }

  revalidatePath("/properties")
}
