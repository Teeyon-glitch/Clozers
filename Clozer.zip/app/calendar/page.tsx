import { Suspense } from "react"
import { CalendarView } from "@/components/calendar/calendar-view"
import { UpcomingEvents } from "@/components/calendar/upcoming-events"
import { CreateEventButton } from "@/components/calendar/create-event-button"
import { Skeleton } from "@/components/ui/skeleton"

export default function CalendarPage() {
  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold tracking-tight">Calendar</h1>
          <p className="text-muted-foreground">Schedule and manage your appointments and events</p>
        </div>
        <CreateEventButton />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Suspense fallback={<Skeleton className="h-[600px]" />}>
            <CalendarView />
          </Suspense>
        </div>

        <div>
          <Suspense fallback={<Skeleton className="h-[600px]" />}>
            <UpcomingEvents />
          </Suspense>
        </div>
      </div>
    </div>
  )
}
