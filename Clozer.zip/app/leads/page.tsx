import { Suspense } from "react"
import { LeadsTable } from "@/components/leads/leads-table"
import { LeadsFilters } from "@/components/leads/leads-filters"
import { CreateLeadButton } from "@/components/leads/create-lead-button"
import { Skeleton } from "@/components/ui/skeleton"

export default function LeadsPage({
  searchParams,
}: {
  searchParams: { search?: string; status?: string; source?: string }
}) {
  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold tracking-tight">Leads</h1>
          <p className="text-muted-foreground">Manage and track all your leads in one place</p>
        </div>
        <CreateLeadButton />
      </div>

      <LeadsFilters />

      <Suspense fallback={<Skeleton className="h-96" />} key={JSON.stringify(searchParams)}>
        <LeadsTable searchParams={searchParams} />
      </Suspense>
    </div>
  )
}
