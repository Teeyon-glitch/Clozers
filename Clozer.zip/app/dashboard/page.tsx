import { Suspense } from "react"
import { DashboardStats } from "@/components/dashboard/dashboard-stats"
import { RevenueChart } from "@/components/dashboard/revenue-chart"
import { LeadSourceChart } from "@/components/dashboard/lead-source-chart"
import { RecentActivity } from "@/components/dashboard/recent-activity"
import { UpcomingTasks } from "@/components/dashboard/upcoming-tasks"
import { Skeleton } from "@/components/ui/skeleton"

export default function DashboardPage() {
  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Welcome back! Here's an overview of your real estate business.</p>
      </div>

      <Suspense fallback={<StatsLoadingSkeleton />}>
        <DashboardStats />
      </Suspense>

      <div className="grid gap-6 md:grid-cols-2">
        <Suspense fallback={<ChartLoadingSkeleton />}>
          <RevenueChart />
        </Suspense>

        <Suspense fallback={<ChartLoadingSkeleton />}>
          <LeadSourceChart />
        </Suspense>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Suspense fallback={<ActivityLoadingSkeleton />}>
          <RecentActivity />
        </Suspense>

        <Suspense fallback={<TasksLoadingSkeleton />}>
          <UpcomingTasks />
        </Suspense>
      </div>
    </div>
  )
}

function StatsLoadingSkeleton() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <Skeleton key={i} className="h-32" />
      ))}
    </div>
  )
}

function ChartLoadingSkeleton() {
  return <Skeleton className="h-80" />
}

function ActivityLoadingSkeleton() {
  return <Skeleton className="h-96" />
}

function TasksLoadingSkeleton() {
  return <Skeleton className="h-96" />
}
