import { Suspense } from "react"
import { PropertiesGrid } from "@/components/properties/properties-grid"
import { PropertiesFilters } from "@/components/properties/properties-filters"
import { CreatePropertyButton } from "@/components/properties/create-property-button"
import { Skeleton } from "@/components/ui/skeleton"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function PropertiesPage({
  searchParams,
}: {
  searchParams: { search?: string; type?: string; priceRange?: string; status?: string }
}) {
  const activeStatus = searchParams.status || "all"

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold tracking-tight">Properties</h1>
          <p className="text-muted-foreground">Manage your property listings and inventory</p>
        </div>
        <CreatePropertyButton />
      </div>

      <Tabs value={activeStatus} className="w-full">
        <TabsList>
          <TabsTrigger value="all">All Properties</TabsTrigger>
          <TabsTrigger value="available">Available</TabsTrigger>
          <TabsTrigger value="under_contract">Under Contract</TabsTrigger>
          <TabsTrigger value="sold">Sold</TabsTrigger>
        </TabsList>

        <TabsContent value={activeStatus} className="space-y-6">
          <PropertiesFilters currentStatus={activeStatus} />
          <Suspense fallback={<GridSkeleton />} key={JSON.stringify(searchParams)}>
            <PropertiesGrid searchParams={{ ...searchParams, status: activeStatus }} />
          </Suspense>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function GridSkeleton() {
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 6 }).map((_, i) => (
        <Skeleton key={i} className="h-96" />
      ))}
    </div>
  )
}
