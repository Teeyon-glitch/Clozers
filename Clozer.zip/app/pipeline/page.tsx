import { Suspense } from "react"
import { PipelineBoard } from "@/components/pipeline/pipeline-board"
import { PipelineStats } from "@/components/pipeline/pipeline-stats"
import { CreateDealButton } from "@/components/pipeline/create-deal-button"
import { Skeleton } from "@/components/ui/skeleton"

export default function PipelinePage() {
  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold tracking-tight">Pipeline</h1>
          <p className="text-muted-foreground">Track deals through your sales pipeline</p>
        </div>
        <CreateDealButton />
      </div>

      <Suspense fallback={<Skeleton className="h-24" />}>
        <PipelineStats />
      </Suspense>

      <Suspense fallback={<Skeleton className="h-[600px]" />}>
        <PipelineBoard />
      </Suspense>
    </div>
  )
}
