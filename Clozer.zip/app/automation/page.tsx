import { Suspense } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { EmailTemplates } from "@/components/automation/email-templates"
import { AutomationWorkflows } from "@/components/automation/automation-workflows"
import { Skeleton } from "@/components/ui/skeleton"

export default function AutomationPage() {
  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Automation & Templates</h1>
        <p className="text-muted-foreground">Streamline your workflow with automated tasks and email templates</p>
      </div>

      <Tabs defaultValue="templates" className="w-full">
        <TabsList>
          <TabsTrigger value="templates">Email Templates</TabsTrigger>
          <TabsTrigger value="workflows">Automation Workflows</TabsTrigger>
        </TabsList>

        <TabsContent value="templates" className="space-y-6">
          <Suspense fallback={<Skeleton className="h-96" />}>
            <EmailTemplates />
          </Suspense>
        </TabsContent>

        <TabsContent value="workflows" className="space-y-6">
          <Suspense fallback={<Skeleton className="h-96" />}>
            <AutomationWorkflows />
          </Suspense>
        </TabsContent>
      </Tabs>
    </div>
  )
}
